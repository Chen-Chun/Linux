https://www.linkedin.com/pulse/deploy-your-first-scaleable-phpmysql-web-application-raghav-agarwal/

steps:
db-pv.yaml
mysql-pvc.yaml
php-pv.yaml
php-pvc.yaml
mydb-dep.yaml
php-dep.yaml
db-service.yaml
php-service.yaml

